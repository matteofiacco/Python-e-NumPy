#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import os
import shutil
import csv
import argparse


# In[ ]:


os.chdir("C:/Users/Fiacco/Downloads/FileOrganizer/FileOrganizer/files")
#cambio la directory di lavoro


# In[ ]:


header=['name','type','size(B)']
if not os.path.exists("recap.csv"):
    with open("recap.csv","wb") as file:
        writer=csv.writer(file)
        writer.writerow(header)
#creo il documento recap se non esiste


# In[ ]:


audio_ext=['.mp3']
docs_ext=['.txt','.odt']
images_ext=['.jpeg','.png','.jpg']
extension=audio_ext+docs_ext+images_ext
#definisco  le variabili con le estensioni accettate


# In[ ]:


def organizzatore(filename,folder,file_type):
    name=os.path.splitext(filename)[0]
    byte=os.path.getsize("{}".format(filename))
    print("{} type:{} size:{}B\nFile spostato con successo!".format(name,file_type,byte))
    if not os.path.exists("{}".format(folder)):
        os.makedirs("{}".format(folder))
    shutil.move("{}".format(filename),"{}".format(folder))
    table=[name,file_type,byte]
    with open("recap.csv","ab") as f:
        writer=csv.writer(f)
        writer.writerow(table)
#definisco una funzione che mi crea la sottocartella se non esiste e mi sposta il file
#stampa le informazioni e le inserisce nel file recap


# In[ ]:


def addfile(filename):
    if filename in os.listdir(os.getcwd()):
        if filename.endswith(tuple(audio_ext)):
            file_type= 'audio'
            organizzatore(filename,'audio',file_type)  
        elif filename.endswith(tuple(docs_ext)):
            file_type= 'doc'
            organizzatore(filename,'docs',file_type)   
        elif filename.endswith(tuple(images_ext)):
            file_type= 'image'
            organizzatore(filename,'images',file_type)
        else:
            print('file format not supported')
    else:
        print('Questi sono i file tra cui puoi scegliere')
        for file in sorted (os.listdir(os.getcwd())):
            if file.endswith(tuple(extension)):
                print(file) 
#definisco una funzione che passato il nome del file
#lo sposta nella sottocartella, ne stampa le informazioni e le inserisce nel file recap


# In[ ]:


parser=argparse.ArgumentParser(
    description='Sposta un file nella relativa sottocartella e aggiorna il file recap')
parser.add_argument('filename',type=str,help='nome del file comprensivo di formato')
args=parser.parse_args()

addfile(args.filename)
#passo allo script gli argomenti da utilizzare tramite linea di comando

